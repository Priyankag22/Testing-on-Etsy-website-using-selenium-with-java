package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SocialLinksRepository
{
	public static WebElement Instagram(WebDriver wd)

	{
		WebElement insta=wd.findElement(By.xpath("//body/div[@id='collage-footer']/footer[1]/div[3]/nav[1]/div[1]/div[1]/div[4]/div[2]/div[1]/ul[1]/li[1]/a[1]/span[1]/*[1]"));
		return insta;
	}

	public static WebElement Facebook(WebDriver wd)

	{
		WebElement fb=wd.findElement(By.xpath("//body/div[@id='collage-footer']/footer[1]/div[3]/nav[1]/div[1]/div[1]/div[4]/div[2]/div[1]/ul[1]/li[2]/a[1]/span[1]/*[1]"));
		return fb;
	}
	public static WebElement pinterest(WebDriver wd)

	{
		WebElement pr=wd.findElement(By.xpath("//body/div[@id='collage-footer']/footer[1]/div[3]/nav[1]/div[1]/div[1]/div[4]/div[2]/div[1]/ul[1]/li[3]/a[1]/span[1]/*[1]"));
		return pr;
	}
	public static WebElement twitter(WebDriver wd)

	{
		WebElement tw=wd.findElement(By.xpath("//body/div[@id='collage-footer']/footer[1]/div[3]/nav[1]/div[1]/div[1]/div[4]/div[2]/div[1]/ul[1]/li[4]/a[1]/span[1]/*[1]"));
		return tw;
	}
	public static WebElement Youtube(WebDriver wd)

	{
		WebElement yt=wd.findElement(By.xpath("//body/div[@id='collage-footer']/footer[1]/div[3]/nav[1]/div[1]/div[1]/div[4]/div[2]/div[1]/ul[1]/li[5]/a[1]/span[1]/*[1]"));
		return yt;
	}
}
