package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class UpdateRepository 
{
	public static WebElement SignIn(WebDriver wd)

	{
		WebElement signin=wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[1]/button[1]"));
		return signin;
	}
	public static WebElement email(WebDriver wd)

	{
		WebElement email=wd.findElement(By.name("email"));
		return email;
	}

	public static WebElement password(WebDriver wd)

	{
		WebElement pswd=wd.findElement(By.name("password"));
		return pswd;
	}

	public static WebElement SignClk(WebDriver wd)

	{
		WebElement Sign=wd.findElement(By.name("submit_attempt"));
		return Sign;
	}
	public static WebElement UpdateClk(WebDriver wd)

	{
		WebElement update=wd.findElement(By.xpath("//header/div[4]/nav[1]/ul[1]/li[2]/div[1]/button[1]/span[2]/*[1]"));
		return update;                            
	}
	public static WebElement Update1(WebDriver wd)

	{
		WebElement update=wd.findElement(By.xpath("//header/div[4]/nav[1]/ul[1]/li[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[1]/a[1]/div[1]/div[1]/div[2]/p[1]"));
		return update;                            
	}
	public static WebElement savelater(WebDriver wd)

	{
		WebElement save=wd.findElement(By.xpath("//span[contains(text(),'Save for later')]"));
		return save;                            
	}
	public static WebElement Update2(WebDriver wd)

	{
		WebElement update=wd.findElement(By.xpath("//header/div[4]/nav[1]/ul[1]/li[2]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/ul[1]/li[2]/a[1]/div[1]/div[1]/div[2]/p[1]"));
		return update;                            
	}
	
}
