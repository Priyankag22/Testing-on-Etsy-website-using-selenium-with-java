package repository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MessageLinkRepository
{
	public static WebElement SignIn(WebDriver wd)

	{
		WebElement signin=wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[1]/button[1]"));
		return signin;
	}
	public static WebElement email(WebDriver wd)

	{
		WebElement email=wd.findElement(By.name("email"));
		return email;
	}

	public static WebElement password(WebDriver wd)

	{
		WebElement pswd=wd.findElement(By.name("password"));
		return pswd;
	}

	public static WebElement SignClk(WebDriver wd)

	{
		WebElement Sign=wd.findElement(By.name("submit_attempt"));
		return Sign;
	}
	public static WebElement arrowclk(WebDriver wd)
	{
		WebElement clkbtn= wd.findElement(By.xpath("/html/body/div[3]/header/div[4]/nav/ul/li[3]/div/button/span[1]/img"));
		return  clkbtn;    							
	}
	public static WebElement MsgClk(WebDriver wd)

	{
		WebElement msg=wd.findElement(By.xpath("//p[contains(text(),'Messages')]"));
		return msg;
	}
	public static WebElement InboxClk(WebDriver wd)

	{
		WebElement Inbox=wd.findElement(By.xpath("//span[contains(text(),'Inbox')]"));
		return Inbox; //
	}
	public static WebElement SendboxClk(WebDriver wd)

	{
		WebElement sendbox=wd.findElement(By.xpath("//span[contains(text(),'Sent')]"));
		return sendbox;
	}
	public static WebElement AllClk(WebDriver wd)

	{
		WebElement All=wd.findElement(By.xpath("//span[contains(text(),'All')]"));
		return All;								
	}
	public static WebElement unreadClk(WebDriver wd)

	{
		WebElement unread=wd.findElement(By.xpath("//span[contains(text(),'Unread')]"));
		return unread;
	}
	public static WebElement SpamClk(WebDriver wd)

	{
		WebElement spam=wd.findElement(By.xpath("//span[contains(text(),'Spam')]"));
		return spam;
	}
	public static WebElement RbinClk(WebDriver wd)

	{
		WebElement Recycle=wd.findElement(By.xpath("//span[contains(text(),'Recycling bin')]"));
		return Recycle;
	}
	
	public static WebElement checkboxclk1(WebDriver wd)

	{
		WebElement Click=wd.findElement(By.xpath("/html/body/div[4]/div/div[1]/div/div/div/div[2]/div[2]/div[1]/div[2]/div[1]/div/div/div/input"));
		return Click;							
												
	}
	
	public static List Clk(WebDriver wd)
	{
		List<WebElement> imgs= wd.findElements(By.cssSelector("img[src='https://www.etsy.com/images/avatars/default_avatar_75x75.png']"));
		return imgs;
	}
	public static WebElement MarkUnread(WebDriver wd)

	{
		WebElement Mu =wd.findElement(By.xpath("//button[contains(text(),'Mark Unread')]"));
		return Mu;

	}
	public static WebElement checkboxclk2(WebDriver wd)

	{
		WebElement Click=wd.findElement(By.xpath("/html/body/div[4]/div/div[1]/div/div/div/div[2]/div[2]/div[1]/div[2]/div[2]/div/div/div/input"));
		return Click;

	}
	public static WebElement Markread(WebDriver wd)

	{
		WebElement Mr =wd.findElement(By.xpath("//button[contains(text(),'Mark Read')]"));
		return Mr;

	}
	public static WebElement checkboxclk3(WebDriver wd)

	{
		WebElement Click=wd.findElement(By.xpath("/html/body/div[4]/div/div[1]/div/div/div/div[2]/div[2]/div[1]/div[2]/div[3]/div/div/div/input"));
		return Click;

	}
	public static WebElement Markspam(WebDriver wd)

	{
		WebElement Ms =wd.findElement(By.xpath("//button[contains(text(),'Mark as Spam')]"));
		return Ms;

	}

	public static WebElement RecycleBinClk(WebDriver wd)

	{
		WebElement Rcb=wd.findElement(By.xpath("//button[contains(text(),'Recycling bin')]"));
		return Rcb;
	}
	
	public static WebElement Searchboxclk(WebDriver wd)

	{
		WebElement search=wd.findElement(By.xpath("//body/div[@id='content']/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/form[1]/div[1]/input[1]"));
		return search;

	}
	public static WebElement msgfetch1(WebDriver wd)

	{
		WebElement msg=wd.findElement(By.xpath("/html/body/div[4]/div/div[1]/div/div/div/div[2]/div[2]/div[1]/h3"));
		return msg;
	}
	public static WebElement msgfetch2(WebDriver wd)

	{
		WebElement msg1= wd.findElement(By.xpath("/html/body/div[4]/div/div[1]/div/div/div/div[2]/div[2]/div[1]/div[2]/div/div/div/h3"));
		return msg1;
	}

}
