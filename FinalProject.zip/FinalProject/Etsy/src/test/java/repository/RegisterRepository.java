package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegisterRepository
{
	public static WebElement signup(WebDriver wd)
	{
		WebElement signup=wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[1]/button[1]"));
		return signup;
	}
	
	public static WebElement registerclk(WebDriver wd)
	{
		WebElement regi= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/div[1]/div[1]/button[1]"));
		return regi;
	}
	
	public static WebElement email(WebDriver wd)
	{
		WebElement email= wd.findElement(By.id("join_neu_email_field"));
		return email;
	}
	public static WebElement Firstname(WebDriver wd)
	{
		WebElement Fname= wd.findElement(By.id("join_neu_first_name_field"));
		return Fname;
	}
	public static WebElement password(WebDriver wd)
	{
		WebElement pswd= wd.findElement(By.id("join_neu_password_field"));
		return  pswd;
	
}
	public static WebElement regis(WebDriver wd)
	{
		WebElement register = wd.findElement(By.name("submit_attempt"));
		return  register;
	
}
	public static WebElement arrowclk(WebDriver wd)
	{
		WebElement clkbtn= wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[3]/div[1]/button[1]/span[1]/img[1]"));
		return  clkbtn;
	
}
	public static WebElement signout(WebDriver wd)
	{
		WebElement signout= wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[3]/div[1]/div[1]/ul[1]/li[6]/a[1]/div[2]/p[1]"));
		return  signout;
	
}
	
	
}


