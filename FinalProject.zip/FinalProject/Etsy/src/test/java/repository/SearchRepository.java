package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchRepository 
{
	public static WebElement search(WebDriver wd)

	{
		WebElement se = wd.findElement(By.id("global-enhancements-search-query"));
		return se;
	}
	public static WebElement button(WebDriver wd)

	{
		WebElement btn=wd.findElement(By.cssSelector("button[value='Search']"));
		return btn;
	}

}
