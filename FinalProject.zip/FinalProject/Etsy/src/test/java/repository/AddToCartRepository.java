package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddToCartRepository
{
	public static WebElement SignIn(WebDriver wd)

	{
		WebElement signin=wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[1]/button[1]"));
		return signin;
	}
	public static WebElement email(WebDriver wd)

	{
		WebElement email=wd.findElement(By.name("email"));
		return email;
	}
	public static WebElement password(WebDriver wd)

	{
		WebElement pswd=wd.findElement(By.name("password"));
		return pswd;
	}
	public static WebElement SignClk(WebDriver wd)

	{
		WebElement Sign=wd.findElement(By.name("submit_attempt"));
		return Sign;
	}
	public static WebElement Search(WebDriver wd)

	{
		WebElement se = wd.findElement(By.id("global-enhancements-search-query"));
		return se;
	}
	public static WebElement NextPage(WebDriver wd)

	{
		WebElement num= wd.findElement(By.xpath("//body[1]/main[1]/div[1]/div[1]/div[1]/div[4]/div[5]/div[3]/div[12]/div[1]/div[1]/div[1]/div[2]/nav[1]/ul[1]/li[3]/a[1]"));
		return num;
	}
	public static WebElement Relevancy (WebDriver wd)

	{
		WebElement aclk= wd.findElement(By.xpath("//body[1]/main[1]/div[1]/div[1]/div[1]/div[4]/div[5]/div[3]/div[6]/div[2]/div[3]/div[1]/button[1]/div[1]/span[1]/span[2]"));
		return aclk;
	}
	public static WebElement highprice(WebDriver wd)

	{
		WebElement hp= wd.findElement(By.linkText("Highest Price"));
		return hp;
	}

	public static WebElement size(WebDriver wd)

	{
		WebElement size= wd.findElement(By.id("inventory-variation-select-0"));
		return size;
	}
	public static WebElement PrimaryColour(WebDriver wd)

	{
		WebElement pc= wd.findElement(By.id("inventory-variation-select-1"));
		return pc;
	}


	public static WebElement Quantity(WebDriver wd)
	{
		WebElement qn= wd.findElement(By.id("listing-page-quantity-select"));
		return qn;
	}
	public static WebElement PriceFetch(WebDriver wd)

	{											
		WebElement msg=wd.findElement(By.xpath("/html/body/main/div[1]/div[1]/div/div/div[1]/div[2]/div/div[3]/div/div[1]/div[1]/div[1]/div[1]/p[1]"));
		return msg;
	}
	public static WebElement AddtoBasket(WebDriver wd)
	{											
		WebElement Atb= wd.findElement(By.xpath("/html/body/main/div[1]/div[1]/div/div/div[1]/div[2]/div/div[3]/div/div[2]/div/form/div/button"));
		return Atb;							
	}
	public static WebElement checkout(WebDriver wd)
	{
		WebElement cout= wd.findElement(By.xpath("//body[1]/div[5]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[2]/div[1]/button[1]/span[1]"));
		return cout;
	}
	public static WebElement skirt(WebDriver wd)

	{
		WebElement hp= wd.findElement(By.xpath("/html/body/main/div/div[1]/div/div[4]/div[5]/div[3]/div[9]/div/div/div[1]/ul/li[2]/div/a/div[2]/div/h3"));
		return hp;
	}
	public static WebElement savelater(WebDriver wd)

	{
		WebElement cb= wd.findElement(By.xpath("/html/body/main/div/div[3]/div[1]/div[1]/div/div[1]/ul/li/ul/li/div/div[2]/div/div[1]/div[4]/ul/li[1]/a/span"));
		return cb;
	}
	public static WebElement signout(WebDriver wd)
	{
		WebElement signout= wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[3]/div[1]/div[1]/ul[1]/li[6]/a[1]/div[2]/p[1]"));
		return  signout;

	}
	public static WebElement arrowclk(WebDriver wd)
	{
		WebElement clkbtn= wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[3]/div[1]/button[1]/span[1]/img[1]"));
		return  clkbtn;
	}
}
