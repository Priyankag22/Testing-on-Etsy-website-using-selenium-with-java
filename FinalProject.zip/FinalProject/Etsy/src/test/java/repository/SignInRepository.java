package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SignInRepository {

	public static WebElement signin(WebDriver wd)
	{
		WebElement signin=wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[1]/button[1]"));
		return signin;
	}
	public static WebElement email(WebDriver wd)
	{
		WebElement email=wd.findElement(By.name("email"));
		return email;
	}
	public static WebElement pass(WebDriver wd)
	{
		WebElement pswd=wd.findElement(By.name("password"));
		return pswd;
	}
	public static WebElement Sign (WebDriver wd)
	{
		WebElement Sign=wd.findElement(By.name("submit_attempt"));
		return Sign;
	}
	public static WebElement arrowclk(WebDriver wd)
	{
		WebElement clkbtn= wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[3]/div[1]/button[1]/span[1]/img[1]"));
		return  clkbtn;
	
}
	public static WebElement signout(WebDriver wd)
	{
		WebElement signout= wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[3]/div[1]/div[1]/ul[1]/li[6]/a[1]/div[2]/p[1]"));
		return  signout;
	
}
	
	
}
