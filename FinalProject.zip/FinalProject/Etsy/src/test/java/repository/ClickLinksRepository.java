package repository;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ClickLinksRepository {

	public static WebElement link1(WebDriver wd)

	{
		WebElement jew = wd.findElement(By.linkText("Jewellery & Accessories"));
		return jew;
	}

	public static WebElement link2(WebDriver wd)

	{

		WebElement bt=wd.findElement(By.id("catnav-l4-12291"));
		return bt;

	}

	public static WebElement link3(WebDriver wd)

	{

		WebElement cs= wd.findElement(By.id("catnav-primary-link-10923"));
		return cs;
	}
	public static WebElement link4(WebDriver wd)

	{
		WebElement sk= wd.findElement(By.id("catnav-l4-10929"));
		return sk;
	}
	public static WebElement toys(WebDriver wd)

	{
		WebElement te= wd.findElement(By.id("catnav-primary-link-11049"));
		return te;
	}

	public static WebElement books(WebDriver wd)

	{
		
		WebElement te= wd.findElement(By.id("catnav-l4-11065"));
		return te;
	}
	public static WebElement Home(WebDriver wd)

	{
		WebElement hl= wd.findElement(By.id("catnav-primary-link-891"));
		return hl;
	}
	
	public static WebElement wallDecor(WebDriver wd)

	{
		WebElement dc= wd.findElement(By.id("catnav-l4-10962"));
		return dc;
	}
	public static WebElement Weddingparty(WebDriver wd)

	{
		WebElement wp= wd.findElement(By.id("catnav-primary-link-10983"));
		return wp;
	}

	public static WebElement bakingcake(WebDriver wd)

	{
		WebElement bc= wd.findElement(By.id("catnav-l3-10986"));
		return bc;
	}
	public static WebElement artcollect(WebDriver wd)

	{
		WebElement ac= wd.findElement(By.id("catnav-primary-link-66"));
		return ac;
	}
	public static WebElement dolls (WebDriver wd)

	{
		WebElement dm= wd.findElement(By.id("catnav-l3-1612"));
		return dm;
	}
	public static WebElement craft(WebDriver wd)

	{
		WebElement craft= wd.findElement(By.id("catnav-primary-link-562"));
		return craft;
	}
	public static WebElement framing(WebDriver wd)

	{
		WebElement fa= wd.findElement(By.id("catnav-l3-9319"));
		return fa;
	}
	public static WebElement vintage(WebDriver wd)

	{
		WebElement vin= wd.findElement(By.xpath("/html/body/div[4]/div[1]/div/ul/li[8]/a/span"));
		return vin;
	}
	
	
	
	
	
}


