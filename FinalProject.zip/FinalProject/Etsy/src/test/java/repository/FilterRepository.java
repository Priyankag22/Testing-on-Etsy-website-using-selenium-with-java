package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class FilterRepository
{
	public static WebElement Search1(WebDriver wd)
	{
		WebElement se = wd.findElement(By.id("global-enhancements-search-query"));
		return se;
	}
	public static WebElement Searchclick(WebDriver wd)
	{
		WebElement clk=wd.findElement(By.cssSelector("button[value='Search']"));
		return clk;
	}
	public static WebElement AllFiler (WebDriver wd)
	{
		WebElement allFilter= wd.findElement(By.xpath("//body[1]/main[1]/div[1]/div[1]/div[1]/div[4]/div[5]/div[3]/div[6]/div[1]/div[2]/button[1]/span[2]"));
		return allFilter;
	}
	public static WebElement Specialoffer(WebDriver wd)
	{
		WebElement so= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/div[2]/fieldset[1]/div[1]/div[1]/div[1]/div[1]/label[1]"));
		return so;
	}
	public static WebElement dispatch (WebDriver wd)
	{
		WebElement rtd= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/div[3]/fieldset[1]/div[1]/div[1]/div[1]/div[1]/label[1]"));
		return rtd;
	}
	public static WebElement customprice (WebDriver wd)
	{
		WebElement cp= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/div[4]/fieldset[1]/div[1]/div[1]/div[2]/div[1]/label[1]"));
		return cp;
	}
	public static WebElement Minprice (WebDriver wd)
	{
		WebElement minp=wd.findElement(By.name("min"));
		return minp;
	}
	public static WebElement maxprice(WebDriver wd)
	{
		WebElement maxp=wd.findElement(By.name("max"));
		return maxp;
	}
	public static WebElement colorwhite(WebDriver wd)
	{
		WebElement cwhite= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/fieldset[1]/div[1]/div[1]/div[1]/div[1]/label[1]"));
		return cwhite;
	}
	public static WebElement colorblack(WebDriver wd)
	{
		WebElement cblack=wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/fieldset[1]/div[1]/div[1]/div[2]/div[1]/label[1]"));
		return cblack;
	}
	public static WebElement colorblue(WebDriver wd)
	{
		WebElement cblue =wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/fieldset[1]/div[1]/div[1]/div[5]/div[1]/label[1]"));
		return cblue;
	}
	public static WebElement showmore(WebDriver wd)
	{
		WebElement sm= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/fieldset[1]/div[1]/button[1]"));
		return sm;
	}
	public static WebElement easter(WebDriver wd)
	{
		WebElement easter= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/fieldset[2]/div[1]/div[1]/div[3]/div[1]/label[1]"));
		return easter;
	}
	public static WebElement fatherDay(WebDriver wd)
	{
		WebElement fd= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/fieldset[2]/div[1]/div[1]/div[4]/div[1]/label[1]"));
		return fd;
	}
	public static WebElement custom(WebDriver wd)
	{
		WebElement custom= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/div[5]/fieldset[1]/div[1]/div[1]/div[3]/div[1]/label[1]"));
		return custom;
	}
	public static WebElement location(WebDriver wd)
	{
		WebElement loc= wd.findElement(By.id("shop-location-input"));
		return loc;
	}
	public static WebElement blankspaceclk(WebDriver wd)
	{
		 WebElement click=wd.findElement(By.xpath("/html[1]/body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/div[5]/fieldset[1]/div[1]"));
		 return click;
	}
	public static WebElement handmade(WebDriver wd)
	{
		WebElement HM= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/div[6]/fieldset[1]/div[1]/div[1]/div[2]/label[1]"));
		return HM;
	}
	public static WebElement customisable(WebDriver wd)
	{
		WebElement cust= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[3]/form[1]/div[1]/div[1]/div[7]/fieldset[1]/div[1]/div[1]/div[3]/div[1]/label[1]"));
		return cust;
	}
	public static WebElement ClickOnApply(WebDriver wd)
	{
		WebElement apply= wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[2]/button[2]"));
		return apply;
	}
	public static WebElement FilterResult(WebDriver wd)
	{
		WebElement msg=wd.findElement(By.xpath("//body[1]/main[1]/div[1]/div[1]/div[1]/div[4]/div[5]/div[3]/div[8]/div[4]/p[1]"));
		return msg;
	}
	
	
	

}
