package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ComposeRepository 
{
	public static WebElement SignIn(WebDriver wd)

	{
		WebElement signin=wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[1]/button[1]"));
		return signin;
	}
	public static WebElement email(WebDriver wd)

	{
		WebElement email=wd.findElement(By.name("email"));
		return email;
	}

	public static WebElement password(WebDriver wd)

	{
		WebElement pswd=wd.findElement(By.name("password"));
		return pswd;
	}

	public static WebElement SignClk(WebDriver wd)

	{
		WebElement Sign=wd.findElement(By.name("submit_attempt"));
		return Sign;
	}
	public static WebElement arrowclk(WebDriver wd)
	{
		WebElement clkbtn= wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[3]/div[1]/button[1]/span[1]/img[1]"));
		return  clkbtn;
	}
	public static WebElement MsgClk(WebDriver wd)

	{
		WebElement msg=wd.findElement(By.xpath("//p[contains(text(),'Messages')]"));
		return msg;
	}
	public static WebElement ComposeClk(WebDriver wd)

	{
		WebElement compose=wd.findElement(By.xpath("//button[contains(text(),'Compose')]"));
		return compose;
	}
	public static WebElement Recipient(WebDriver wd)

	{
		WebElement rece=wd.findElement(By.xpath("/html/body/div[7]/div[2]/div/div[3]/div/div[2]/div[1]/div[1]/input"));
		return rece;
	}
	public static WebElement subject(WebDriver wd)

	{
		WebElement sub=wd.findElement(By.xpath("/html/body/div[7]/div[2]/div/div[3]/div/div[2]/div[1]/div[2]/input"));
		return sub;
	}
	public static WebElement Message(WebDriver wd)

	{
		WebElement msg=wd.findElement(By.xpath("/html/body/div[7]/div[2]/div/div[3]/div/div[2]/div[1]/div[3]/div[1]/div/div/textarea"));
		return msg;
	}
	public static WebElement send(WebDriver wd)

	{
		WebElement send=wd.findElement(By.xpath("//button[contains(text(),'Send')]"));
		return send;
	}
	public static WebElement signout(WebDriver wd)
	{
		WebElement signout= wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[3]/div[1]/div[1]/ul[1]/li[6]/a[1]/div[2]/p[1]"));
		return  signout;
	
}
	public static WebElement MsgFetch(WebDriver wd)

	{
		WebElement text=wd.findElement(By.xpath("//h3[contains(text(),'No conversations to see here!')]"));
		return text;
	}
	


}
