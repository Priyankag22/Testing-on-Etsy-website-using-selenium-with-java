package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AddToFavouritesRepository 
{
	public static WebElement SignIn(WebDriver wd)

	{
		WebElement signin=wd.findElement(By.xpath("//body[1]/div[3]/header[1]/div[4]/nav[1]/ul[1]/li[1]/button[1]"));
		return signin;
	}
	public static WebElement email(WebDriver wd)

	{
		WebElement email=wd.findElement(By.name("email"));
		return email;
	}

	public static WebElement password(WebDriver wd)

	{
		WebElement pswd=wd.findElement(By.name("password"));
		return pswd;
	}

	public static WebElement SignClk(WebDriver wd)

	{
		WebElement Sign=wd.findElement(By.name("submit_attempt"));
		return Sign;
	}

	public static WebElement Search(WebDriver wd)

	{
		WebElement se = wd.findElement(By.id("global-enhancements-search-query"));
		return se;
	}

	public static WebElement Favitem1(WebDriver wd)

	{
		WebElement fav1= wd.findElement(By.xpath("//body/main[@id='content']/div[1]/div[1]/div[1]/div[4]/div[5]/div[3]/div[9]/div[1]/div[1]/div[1]/ul[1]/li[3]/div[1]/a[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/img[1]"));
		return fav1;
	}
	public static WebElement add(WebDriver wd)

	{												
		WebElement add1= wd.findElement(By.xpath("//body/main[@id='content']/div[1]/div[1]/div[1]/div[4]/div[5]/div[3]/div[9]/div[1]/div[1]/div[1]/ul[1]/li[2]/div[1]/div[1]/button[1]/div[1]/span[1]/*[1]"));
		return add1;
	}
	public static WebElement Favitem2(WebDriver wd)
	
	{		
		WebElement fav2=wd.findElement(By.xpath("//body/main[@id='content']/div[1]/div[1]/div[1]/div[4]/div[5]/div[3]/div[9]/div[1]/div[1]/div[1]/ul[1]/li[2]/div[1]/a[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/img[1]"));
		return fav2;
	}
	public static WebElement Favitem3(WebDriver wd)

	{
		WebElement fav3 = wd.findElement(By.xpath("//body/main[@id='content']/div[1]/div[1]/div[1]/div[4]/div[5]/div[3]/div[9]/div[1]/div[1]/div[1]/ul[1]/li[1]/div[1]/a[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/img[1]"));
		return fav3;
	}
	public static WebElement ClickOnFav(WebDriver wd)

	{
		WebElement h= wd.findElement(By.xpath("//header/div[4]/nav[1]/ul[1]/li[1]/span[1]/a[1]/span[1]/*[1]"));
		return h;
	}
	public static WebElement msgfetch(WebDriver wd)

	{
		WebElement msg = wd.findElement(By.xpath("/html/body/div[4]/div/div[4]/div/div/div[1]/p[1]"));
		return msg;
	}
	public static WebElement msgfetch2(WebDriver wd)

	{
		WebElement msg = wd.findElement(By.xpath("/html/body/div[4]/div/div[3]/div/div/div/fieldset/div/div/a[1]/span/div/p"));
		return msg;
	}



}
