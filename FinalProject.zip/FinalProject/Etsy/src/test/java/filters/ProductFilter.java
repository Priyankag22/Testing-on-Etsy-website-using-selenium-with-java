package filters;

import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import repository.FilterRepository;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class ProductFilter {
	WebDriver wd;
	@Test
	public void Filters() throws InterruptedException 
	{
		FilterRepository.Search1(wd).sendKeys("shirt");
		FilterRepository.Searchclick(wd).click();
		wd.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		//Click on All filter
		FilterRepository.AllFiler(wd).click();
		
		//click on special offer
		FilterRepository.Specialoffer(wd).click();
		wd.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		
		//click on dispatch
		FilterRepository.dispatch(wd).click();

		//click on price
		FilterRepository.customprice(wd).click();
		FilterRepository.Minprice(wd).sendKeys("300");
		FilterRepository.maxprice(wd).sendKeys("600");
		
		//click on colors
		FilterRepository.colorwhite(wd).click();
		FilterRepository.colorblack(wd).click();
		FilterRepository.colorblue(wd).click();
		FilterRepository.showmore(wd).click();
		
		//click on celebration
		wd.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
		FilterRepository.easter(wd).click();
		FilterRepository.fatherDay(wd).click();
		
		
		//click on location		
		FilterRepository.custom(wd).click();
		Thread.sleep(3000);
		FilterRepository.location(wd).sendKeys("pune");
		Thread.sleep(2000);
		FilterRepository.location(wd).sendKeys(Keys.ARROW_UP);
		Thread.sleep(3000);
		FilterRepository.blankspaceclk(wd).click();	
		
		wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		//click on item type
		
		FilterRepository.handmade(wd).click();
		
		
		//click on ordering option
		FilterRepository.customisable(wd).click();
		
		
		//click on apply
		FilterRepository.ClickOnApply(wd).click();
		
		
		// filter result
		
		WebElement msg=FilterRepository.FilterResult(wd);
		System.out.println( " The result of Filter:   " +msg.getText());
	
	}

	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
