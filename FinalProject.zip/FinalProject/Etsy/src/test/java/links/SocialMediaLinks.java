package links;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.SocialLinksRepository;

import org.testng.annotations.BeforeTest;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SocialMediaLinks 
{
	WebDriver wd;
	@Test
	public void links() throws InterruptedException 
	{
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)wd;
		js.executeScript("window.scrollBy(0, 6000)");

		String win = wd.getWindowHandle();	
		SocialLinksRepository.Instagram(wd).click();
		SwitchingWindow.switchW(wd);
		System.out.println("Instagram:  ");
		System.out.println(" URL of the page is:  " +wd.getCurrentUrl());
		Thread.sleep(2000);
		System.out.println(" Title of the page is:  "+wd.getTitle());
		Thread.sleep(2000);
		 
		wd.close();
		wd.switchTo().window(win);
		Thread.sleep(2000);
		SocialLinksRepository.Facebook(wd).click();
		SwitchingWindow.switchW(wd);
		System.out.println("Facebook: ");
		System.out.println(" URL of the page is:  "+wd.getCurrentUrl());
		Thread.sleep(2000);
		System.out.println(" Title of the page is:  "+wd.getTitle());
		Thread.sleep(2000);
		
		wd.close();
		wd.switchTo().window(win);
		Thread.sleep(2000);
		SocialLinksRepository.pinterest(wd).click();
		SwitchingWindow.switchW(wd);
		System.out.println("Pinterest: ");
		System.out.println(" URL of the page is:  "+wd.getCurrentUrl());
		Thread.sleep(2000);
		System.out.println(" Title of the page is:  "+wd.getTitle());
		Thread.sleep(2000);
		
		wd.close();
		wd.switchTo().window(win);
		Thread.sleep(2000);
		SocialLinksRepository.twitter(wd).click();
		SwitchingWindow.switchW(wd);
		System.out.println("Twitter: ");
		System.out.println(" URL of the page is:  "+wd.getCurrentUrl());
		Thread.sleep(2000);
		System.out.println(" Title of the page is:  "+wd.getTitle());
		Thread.sleep(2000);
		
		wd.close();
		wd.switchTo().window(win);
		Thread.sleep(2000);
		SocialLinksRepository.Youtube(wd).click();
		SwitchingWindow.switchW(wd);
		System.out.println("You Tube: ");
		System.out.println(" URL of the page is:  "+wd.getCurrentUrl());
		Thread.sleep(2000);
		System.out.println(" Title of the page is:  "+wd.getTitle());
		
		wd.switchTo().window(win);
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");


	}

	@AfterTest
	public void afterTest() 
	{
		wd.quit();
	}

}
