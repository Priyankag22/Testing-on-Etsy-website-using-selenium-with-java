package links;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class GetTitleCompare 
{
	WebDriver wd;
	@Test
	public void Title() 
	{
		WebElement hd= wd.findElement(By.linkText("Home Decor"));
		hd.click();
		String t1= wd.getTitle(); //actual title
		System.out.println("Title of the page is:"  +t1);
		String t2="Home Decor | Etsy IN";
		if(t1.equalsIgnoreCase(t2))
		{
			System.out.println("This link is working");
		}

		else
		{
			System.out.println("This link is not working");
		}
		wd.navigate().back();
		WebElement og= wd.findElement(By.linkText("Outdoor & Garden"));
		og.click();
		String t3= wd.getTitle(); //actual title
		System.out.println("Title of the page is:"  +t3);
		String t4="Outdoor patio | Etsy IN";
		if(t3.equalsIgnoreCase(t4))
		{
			System.out.println("This link is working");
		}

		else
		{
			System.out.println("This link is not working");
		}
		wd.navigate().back();
		WebElement kd= wd.findElement(By.linkText("Kitchen & Dining"));
		kd.click();
		String t5= wd.getTitle(); //actual title
		System.out.println("Title of the page is:"  +t5);
		String t6="Kitchen | Etsy IN";
		if(t5.equalsIgnoreCase(t6))
		{
			System.out.println("This link is working");
		}

		else
		{
			System.out.println("This link is not working");
		}
		wd.navigate().back();
		WebElement ne= wd.findElement(By.linkText("Necklaces"));
		ne.click();
		String t9= wd.getTitle(); //actual title
		System.out.println("Title of the page is:"  +t9);
		String t10="Handmade jewelry | Etsy IN";
		if(t9.equalsIgnoreCase(t10))
		{
			System.out.println("This link is working");
		}

		else
		{
			System.out.println("This link is not working");
		}
		wd.navigate().back();
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Actions act= new Actions(wd);
		WebElement HL = wd.findElement(By.linkText("Home & Living"));
		Action a= act.moveToElement(HL).build();
		a.perform();
		WebElement ch= wd.findElement(By.xpath("//body[1]/div[4]/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/section[1]/div[1]/ul[1]/li[1]/ul[1]/li[4]/a[1]"));
		ch.click();
		String t7= wd.getTitle(); //actual title
		System.out.println("Title of the page is:"  +t7);
		String t8="Candles & Holders | Etsy IN";
		wd.navigate().back();
		if(t7.equalsIgnoreCase(t8))
		{
			System.out.println("This link is working");
		}

		else
		{
			System.out.println("This link is not working");
		}
		
		WebElement sc= wd.findElement(By.linkText("Self care"));
		sc.click();
		String t11= wd.getTitle(); //actual title
		System.out.println("Title of the page is:"  +t11);
		String t12="Self care | Etsy IN";
		if(t11.equalsIgnoreCase(t12))
		{
			System.out.println("This link is working");
		}

		else
		{
			System.out.println("This link is not working");
		}
		wd.navigate().back();

		WebElement os= wd.findElement(By.linkText("On Sale"));
		os.click();
		String t13= wd.getTitle(); //actual title
		System.out.println("Title of the page is:"  +t13);
		String t14="Gifts | Etsy IN";
		if(t13.equalsIgnoreCase(t14))
		{
			System.out.println("This link is working");
		}

		else
		{
			System.out.println("This link is not working");
		}
		wd.navigate().back();


	}


	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");  
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();  
	}

}
