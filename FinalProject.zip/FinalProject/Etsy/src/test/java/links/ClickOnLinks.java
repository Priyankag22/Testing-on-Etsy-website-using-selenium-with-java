package links;

import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import repository.ClickLinksRepository;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class ClickOnLinks 
{
	WebDriver wd;
	@Test
	public void Click() throws InterruptedException 
	{
		Thread.sleep(2000);

		ClickLinksRepository.link1(wd).click();
		Actions act= new Actions(wd);
		WebElement jew = ClickLinksRepository.link1(wd);
		Action a= act.moveToElement(jew).build();
		a.perform();
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ClickLinksRepository.link2(wd).click();
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ClickLinksRepository.link3(wd).click();
		WebElement cs = ClickLinksRepository.link3(wd);
		Action a1= act.moveToElement(cs).build();
		a1.perform();
		ClickLinksRepository.link4(wd).click();
		
		wd.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		ClickLinksRepository.Home(wd).click();
		Thread.sleep(2000);
		WebElement hl= ClickLinksRepository.Home(wd);
		Action a3= act.moveToElement(hl).build();
		a3.perform();
		ClickLinksRepository.wallDecor(wd).click();
		
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ClickLinksRepository.Weddingparty(wd).click();
		Thread.sleep(2000);
		WebElement wp = ClickLinksRepository.Weddingparty(wd);
		Action a4= act.moveToElement(wp).build();
		a4.perform();
		ClickLinksRepository.bakingcake(wd).click();
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ClickLinksRepository.toys(wd).click();
		Thread.sleep(2000);
		WebElement te = ClickLinksRepository.toys(wd);
		Action a2= act.moveToElement(te).build();
		a2.perform();
		ClickLinksRepository.books(wd).click();
		
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ClickLinksRepository.artcollect(wd).click();
		Thread.sleep(2000);
		WebElement art = ClickLinksRepository.artcollect(wd);
		Action a5= act.moveToElement(art).build();
		a5.perform();
		ClickLinksRepository.dolls(wd).click();
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ClickLinksRepository.craft(wd).click();
		Thread.sleep(2000);
		WebElement craft = ClickLinksRepository.craft(wd);
		Action a6= act.moveToElement(craft).build();
		a6.perform();
		ClickLinksRepository.framing(wd).click();
		
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		ClickLinksRepository.vintage(wd).click();
		
		
		
		
		
		
		
		
	}
	
	@BeforeTest
	public void beforeTest()
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close(); 

	}

}
