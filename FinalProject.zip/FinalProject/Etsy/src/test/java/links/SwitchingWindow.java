package links;

import org.openqa.selenium.WebDriver;

public class SwitchingWindow 
{
	public static void switchW(WebDriver wd) 
	{
		for(String win2 : wd.getWindowHandles() )
		{
			wd.switchTo().window(win2);
		}

	}

}
