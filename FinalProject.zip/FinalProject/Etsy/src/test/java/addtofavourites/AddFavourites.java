package addtofavourites;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.AddToFavouritesRepository;
import repository.ClickLinksRepository;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class AddFavourites 
{
	WebDriver wd;
	@Test
	public void Favourites() throws InterruptedException 
	{
		AddToFavouritesRepository.SignIn(wd).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		AddToFavouritesRepository.email(wd).sendKeys("pvghadage@gmail.com");
		AddToFavouritesRepository.password(wd).sendKeys("vishakha");
		AddToFavouritesRepository.SignClk(wd).click();
		Thread.sleep(5000);
		AddToFavouritesRepository.ClickOnFav(wd).click();

		WebElement msg=AddToFavouritesRepository.msgfetch(wd);
		System.out.println("Before adding Favourite items quntity is:"  +msg.getText());
		wd.navigate().back();
		
		AddToFavouritesRepository.Search(wd).sendKeys("ring");
		AddToFavouritesRepository.Search(wd).sendKeys(Keys.ENTER);
	
		Actions act= new Actions(wd);
		WebElement fav1= AddToFavouritesRepository.Favitem1(wd);
		Action a= act.moveToElement(fav1).build();
		a.perform();
		
		wd.manage().timeouts().implicitlyWait(20 , TimeUnit.SECONDS);
		AddToFavouritesRepository.add(wd).click();
		wd.manage().timeouts().implicitlyWait(30 , TimeUnit.SECONDS);
		wd.navigate().back();
		AddToFavouritesRepository.Search(wd).sendKeys("shirt");
		AddToFavouritesRepository.Search(wd).sendKeys(Keys.ENTER);
		
		wd.manage().timeouts().implicitlyWait(30 , TimeUnit.SECONDS);
		WebElement fav2=AddToFavouritesRepository.Favitem2(wd);
		Action a1=act.moveToElement(fav2).build();
		a1.perform();
		Thread.sleep(5000);
		AddToFavouritesRepository.add(wd).click();
		wd.manage().timeouts().implicitlyWait(30 , TimeUnit.SECONDS);
		wd.navigate().back();
		
		AddToFavouritesRepository.Search(wd).sendKeys("shoes");
		AddToFavouritesRepository.Search(wd).sendKeys(Keys.ENTER);
		wd.manage().timeouts().implicitlyWait(30 , TimeUnit.SECONDS);
		WebElement fav3=AddToFavouritesRepository.Favitem3(wd);
		Action a2=act.moveToElement(fav3).build();
		a2.perform();
		Thread.sleep(5000);
		AddToFavouritesRepository.add(wd).click();
		wd.manage().timeouts().implicitlyWait(30 , TimeUnit.SECONDS);
		wd.navigate().back();
		AddToFavouritesRepository.ClickOnFav(wd).click();
		WebElement msg2=AddToFavouritesRepository.msgfetch2(wd);
		System.out.println(" After Adding Favourite item quntity is :"  +msg2.getText());
	}
	@BeforeTest
	public void beforeTest() 
	{

		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
