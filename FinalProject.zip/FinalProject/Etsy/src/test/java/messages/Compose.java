package messages;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.ComposeRepository;
import repository.MessageLinkRepository;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Compose 
{
	WebDriver wd;
	@Test
	public void ComposeMessage() throws InterruptedException 
	{
		ComposeRepository.SignIn(wd).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ComposeRepository.email(wd).sendKeys("pvghadage@gmail.com");
		ComposeRepository.password(wd).sendKeys("vishakha");
		ComposeRepository.SignClk(wd).click();
		ComposeRepository.arrowclk(wd).click();
		ComposeRepository.MsgClk(wd).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		ComposeRepository.ComposeClk(wd).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		
		ComposeRepository.Recipient(wd).sendKeys("priyanka");
		
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ComposeRepository.subject(wd).sendKeys("nothing");
		ComposeRepository.Message(wd).sendKeys(" how are u?");
		ComposeRepository.send(wd).click();
		
		ComposeRepository.arrowclk(wd).click();
		
		ComposeRepository.signout(wd).click();
		
		
		ComposeRepository.SignIn(wd).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		ComposeRepository.email(wd).sendKeys("priyankaghadage22@yahoo.com");
		ComposeRepository.password(wd).sendKeys("sharupriya@0620");
		ComposeRepository.SignClk(wd).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		ComposeRepository.arrowclk(wd).click();
		ComposeRepository.MsgClk(wd).click();
		
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement msg=ComposeRepository.MsgFetch(wd);
		System.out.println("Inbox Messages:" +msg.getText());
		
		
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/"); 
	}

	@AfterTest
	public void afterTest() 
	{
		//wd.close();
	}

}
