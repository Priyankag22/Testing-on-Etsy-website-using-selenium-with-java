package messages;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.AddToFavouritesRepository;
import repository.MessageLinkRepository;

import org.testng.annotations.BeforeTest;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class MessageLinks 
{
	WebDriver wd;
	@Test
	public void MsgLinks() throws InterruptedException 
	{
		MessageLinkRepository.SignIn(wd).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		MessageLinkRepository.email(wd).sendKeys("pvghadage@gmail.com");
		MessageLinkRepository.password(wd).sendKeys("vishakha");
		MessageLinkRepository.SignClk(wd).click();
		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

		MessageLinkRepository.arrowclk(wd).click();
		MessageLinkRepository.MsgClk(wd).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		MessageLinkRepository.AllClk(wd).click();  
		
		Thread.sleep(2000);

		JavascriptExecutor js=(JavascriptExecutor)wd;	
		js.executeScript("arguments[0].click();", MessageLinkRepository.checkboxclk1(wd));
		MessageLinkRepository.MarkUnread(wd).click();

		Thread.sleep(2000);
		js.executeScript("arguments[0].click();", MessageLinkRepository.checkboxclk2(wd));
		MessageLinkRepository.Markread(wd).click();

		Thread.sleep(2000);
		js.executeScript("arguments[0].click();", MessageLinkRepository.checkboxclk3(wd));
		MessageLinkRepository.Markspam(wd).click();

		
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		MessageLinkRepository.InboxClk(wd).click();
		int size=MessageLinkRepository.Clk(wd).size();
		System.out.println("No. of inbox messages are: " +(size));
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		MessageLinkRepository.SendboxClk(wd).click(); 
		Thread.sleep(3000);
		int size1=MessageLinkRepository.Clk(wd).size();
		System.out.println("No. of sent messages are: " +(size1));


		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		MessageLinkRepository.AllClk(wd).click();  
		Thread.sleep(3000);
		int size2=MessageLinkRepository.Clk(wd).size();
		System.out.println("No. of All messages are: " +(size2));

		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		MessageLinkRepository.unreadClk(wd).click(); 
		Thread.sleep(3000);
		int size3=MessageLinkRepository.Clk(wd).size();
		System.out.println("No. of unread messages are: " +(size3));


		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		MessageLinkRepository.SpamClk(wd).click(); 
		Thread.sleep(3000);
		int size4=MessageLinkRepository.Clk(wd).size();
		System.out.println("No. of spam messages are: " +(size4));

		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		MessageLinkRepository.RbinClk(wd).click(); 
		Thread.sleep(3000);
		int size5=MessageLinkRepository.Clk(wd).size();
		System.out.println("No. of Recycling bin messages are: " +(size5));

		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		MessageLinkRepository.Searchboxclk(wd).sendKeys("Hello");
		MessageLinkRepository.Searchboxclk(wd).sendKeys(Keys.ENTER);

		WebElement msg= MessageLinkRepository.msgfetch1(wd);
		System.out.println("Result of search : "  +msg.getText());

		MessageLinkRepository.Searchboxclk(wd).clear();

		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		MessageLinkRepository.Searchboxclk(wd).sendKeys("xyzd");
		MessageLinkRepository.Searchboxclk(wd).sendKeys(Keys.ENTER);

		WebElement msg1=MessageLinkRepository.msgfetch2(wd);
		System.out.println("Result of search : "  +msg1.getText());

	}


	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/"); 
	}

	@AfterTest
	public void afterTest() 
	{
		//wd.close();
	}

}
