package account;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.RegisterRepository;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Register {
	WebDriver wd;
	@Test

	public void register() throws InterruptedException, IOException 
	{
		RegisterRepository.signup(wd).click(); //signup click
		Thread.sleep(2000);
		RegisterRepository.registerclk(wd).click();
		wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		// for referring the file we want to open
		File f=new File("Data/Register.xlsx");

		//for opening the file in read mode
		FileInputStream fis= new FileInputStream(f);

		// for referring the file we want to read
		XSSFWorkbook wk= new XSSFWorkbook(fis);
		XSSFSheet sh= wk.getSheet("Sheet1");

		int size1=sh.getLastRowNum();
		for(int i=2; i<=size1; i++)
		{
			String e= sh.getRow(i).getCell(0).toString();
			String fn= sh.getRow(i).getCell(1).toString();
			String p=sh.getRow(i).getCell(2).toString();
			System.out.print(e+ "  |  "   +fn + "  |   " +p  );
			RegisterRepository.email(wd).sendKeys(e);
			RegisterRepository.Firstname(wd).sendKeys(fn);
			RegisterRepository.password(wd).sendKeys(p);
			RegisterRepository.regis(wd).click();
			wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			try
			{
				RegisterRepository.arrowclk(wd).click();
				RegisterRepository.signout(wd).click();

			}
			catch(Exception e1)
			{
				RegisterRepository.email(wd).clear();
				RegisterRepository.Firstname(wd).clear();
				RegisterRepository.password(wd).clear();
				System.out.print("-----------Invalid username/ password");
			}
			System.out.println();
		}
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");

	}

	@AfterTest
	public void afterTest()
	{
		wd.close();

	}

}
