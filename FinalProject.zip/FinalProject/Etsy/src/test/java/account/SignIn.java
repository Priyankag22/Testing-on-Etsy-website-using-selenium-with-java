package account;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.RegisterRepository;
import repository.SignInRepository;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SignIn 
{
	WebDriver wd;
	@Test
	public void signIn() throws IOException 
	{
		SignInRepository.signin(wd).click();

		// for referring the file we want to open
		File f=new File("Data/Register.xlsx");

		//for opening the file in read mode
		FileInputStream fis= new FileInputStream(f);

		// for referring the file we want to read
		XSSFWorkbook wk= new XSSFWorkbook(fis);
		XSSFSheet sh= wk.getSheet("Sheet2");

		int size1=sh.getLastRowNum();
		for(int i=1; i<size1; i++)
		{
			String e= sh.getRow(i).getCell(0).toString();
			String p= sh.getRow(i).getCell(1).toString();
			System.out.print(e+ "  |  "  +p  );
			SignInRepository.email(wd).sendKeys(e);
			SignInRepository.pass(wd).sendKeys(p);
			//WebElement check=wd.findElement(By.xpath("//body[1]/div[6]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/form[1]/div[1]/div[1]/div[6]/div[1]/div[1]/label[1]"));
			//check.click();
			SignInRepository.Sign(wd).click();
			wd.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			try
			{
				
				SignInRepository.arrowclk(wd).click();
				SignInRepository.signout(wd).click();
				SignInRepository.signin(wd).click();
				wd.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

			}
			
			catch(Exception e1)
			{
				
				SignInRepository.email(wd).clear();
				SignInRepository.pass(wd).clear();
				System.out.print("-----------Invalid username/ password");
			}
			System.out.println();
		}
	}
	@BeforeTest
	public void beforeTest()
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
