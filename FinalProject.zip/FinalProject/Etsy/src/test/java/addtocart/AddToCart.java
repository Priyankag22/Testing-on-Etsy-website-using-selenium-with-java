package addtocart;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.AddToCartRepository;
import repository.ComposeRepository;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;

public class AddToCart 
{
	WebDriver wd;
	@Test
	public void ATC() throws InterruptedException
	{  
		
		//SignIn
		wd.manage().timeouts().implicitlyWait(5 , TimeUnit.SECONDS);
		AddToCartRepository.SignIn(wd).click();
		AddToCartRepository.email(wd).sendKeys("pvghadage@gmail.com");
		AddToCartRepository.password(wd).sendKeys("vishakha");
		AddToCartRepository.SignClk(wd).click();
		Thread.sleep(6000);
		
		//Search the Product
		Thread.sleep(5000);
		AddToCartRepository.Search(wd).sendKeys("Summer Cotton Skirt Casual Loose Skirts A-line Pleated Elastic Waist Skirt Flared Midi Skirts Customized Plus Size Skirt Boho Linen");
		AddToCartRepository.Search(wd).sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)wd;
		
		String win = wd.getWindowHandle();	// storing the current window handle
		AddToCartRepository.skirt(wd).click();
		for(String win1 : wd.getWindowHandles())
		{
			wd.switchTo().window(win1);			//  Switching to new window opened
		}
		
		js.executeScript("window.scrollBy(0, 300)");
		
		wd.manage().timeouts().implicitlyWait(10 , TimeUnit.SECONDS);
		
		
		AddToCartRepository.size(wd).click();
		AddToCartRepository.size(wd).sendKeys(Keys.ARROW_DOWN);
		AddToCartRepository.size(wd).sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		
		//js.executeScript("window.scrollBy(0, 500)");
		
		AddToCartRepository.PrimaryColour(wd).click();
		AddToCartRepository.PrimaryColour(wd).sendKeys(Keys.ARROW_DOWN);
		AddToCartRepository.PrimaryColour(wd).sendKeys(Keys.ARROW_DOWN);
		AddToCartRepository.PrimaryColour(wd).sendKeys(Keys.ENTER);
		//js.executeScript("window.scrollBy(0, 100)");

		
		wd.manage().timeouts().implicitlyWait(10 , TimeUnit.SECONDS);
		WebElement msg=AddToCartRepository.PriceFetch(wd);
		System.out.println(" Price Of the Skirt is :  "  + msg.getText());
		
		
		Thread.sleep(5000);
		
		AddToCartRepository.AddtoBasket(wd).click();
		
		Thread.sleep(5000);
		AddToCartRepository.savelater(wd).click();
		
		Thread.sleep(5000);
		AddToCartRepository.arrowclk(wd).click();
		
		AddToCartRepository.signout(wd).click();
		
		
	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");
	}

	@AfterTest
	public void afterTest() 
	{
		wd.quit();
	}

}
