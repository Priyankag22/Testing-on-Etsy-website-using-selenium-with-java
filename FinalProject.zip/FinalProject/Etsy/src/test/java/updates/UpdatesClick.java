package updates;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import links.SwitchingWindow;
import repository.ComposeRepository;
import repository.UpdateRepository;

import org.testng.annotations.BeforeTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class UpdatesClick 
{
	WebDriver wd;
	@Test
	public void Updtes() throws InterruptedException 
	{

		UpdateRepository.SignIn(wd).click();
		wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		UpdateRepository.email(wd).sendKeys("pvghadage@gmail.com");
		UpdateRepository.password(wd).sendKeys("vishakha");
		UpdateRepository.SignClk(wd).click();


		//wd.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(5000);
		UpdateRepository.UpdateClk(wd).click();

		String win = wd.getWindowHandle();	
		Thread.sleep(3000);

		UpdateRepository.Update1(wd).click();

		SwitchingWindow.switchW(wd);
		UpdateRepository.savelater(wd).click();
		Thread.sleep(5000);
		UpdateRepository.UpdateClk(wd).click();
		Thread.sleep(5000);
		UpdateRepository.Update2(wd).click();

		SwitchingWindow.switchW(wd);
		
		Thread.sleep(5000);




	}
	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");

	}

	@AfterTest
	public void afterTest() 
	{
		wd.quit();
	}

}
