package searchproduct;

import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import junit.framework.Assert;
import repository.SearchRepository;

import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;

public class Search
{
	WebDriver wd;
	@Test
	public void f() throws IOException
	{
		//for referring the file we want to open
		File f=new File("Data/SearchData.xlsx");

		//for opening the file in read mode
		FileInputStream fis=new FileInputStream(f);

		XSSFWorkbook wk=new XSSFWorkbook(fis);

		//for referring the sheet we want to read
		XSSFSheet sh= wk.getSheet("Sheet1");	


		int size1=sh.getLastRowNum();
		for(int i=1; i<=size1; i++)
		{
			String sd= sh.getRow(i).getCell(0).toString();
			System.out.println(sd);
			SearchRepository.search(wd).sendKeys(sd);
			SearchRepository.button(wd).click();


			try 
			{
				wd.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);

				String s= wd.findElement(By.xpath("/html/body/main/div/div[1]/div/div[4]/div[5]/div[3]/div[6]/div[2]/div[1]/span/span/span[1]")).getText();
				System.out.println(s+ " found");

			}
			catch(Exception e)
			{
				wd.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS);
				WebElement msg=wd.findElement(By.xpath("//body[1]/main[1]/div[1]/div[1]/div[1]/div[4]/div[5]/div[3]/div[8]/div[4]/p[1]"));

				System.out.println(msg.getText());

			}
			SearchRepository.search(wd).clear();
		}
	}









	@BeforeTest
	public void beforeTest() 
	{
		WebDriverManager.chromedriver().setup();
		wd=new ChromeDriver();
		wd.manage().window().maximize();
		wd.get("https://www.etsy.com/in-en/");

	}

	@AfterTest
	public void afterTest() 
	{
		wd.close();
	}

}
